import mysql.connector
import random
import uuid
from datetime import datetime, timedelta
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

db_config = {
    'host': os.environ['DB_HOST'],
    'user': os.environ['DB_USER'],
    'password': os.environ['DB_PASSWORD'],
    'database': os.environ['DB_NAME']
}

PLATES_PER_DISHWASHER = 6
EFFICIENCY_THRESHOLD = 0.6
SHIFT_DURATION_HOURS = 24
INTERVAL_MINUTES = 15
DISHWASHER_MODELS = ['D567', 'D568']

def truncate_tables(cursor, conn):
    tables = ['production_metrics', 'dishwasher_assembly_batches', 'quality_tests', 
              'metal_plate_batches', 'maintenance_logs', 'fabrication_orders']
    for table in tables:
        cursor.execute(f"TRUNCATE TABLE {table}")
    conn.commit()

def lambda_handler(event, context):
    conn = None
    cursor = None
    
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        truncate_tables(cursor, conn)
        
        now = datetime.now()
        twenty_four_hours_ago = now - timedelta(hours=24)
        minutes = twenty_four_hours_ago.minute
        quarter_minutes = (minutes // 15) * 15
        shift_start = twenty_four_hours_ago.replace(minute=quarter_minutes, second=0, microsecond=0)
        shift_end = shift_start + timedelta(hours=SHIFT_DURATION_HOURS)

        
        fabrication_orders = {}
        for model in DISHWASHER_MODELS:
            fabrication_orders[model] = check_fabrication_order(cursor, conn, model, shift_start)
        
        current_time = shift_start
        interval_count = 0
        total_plates_produced = 0
        total_dishwashers_produced = 0
        model_totals = {model: {'plates': 0, 'dishwashers': 0} for model in DISHWASHER_MODELS}
        
        while current_time < shift_end:
            interval_count += 1
            check_and_complete_maintenance(cursor, conn, current_time)
            
            for model in DISHWASHER_MODELS:
                fabrication_order = fabrication_orders[model]
                metal_plates = produce_metal_plates(cursor, conn, fabrication_order, current_time)
                total_plates_produced += metal_plates['quantity']
                model_totals[model]['plates'] += metal_plates['quantity']
                
                handle_efficiency_based_maintenance(cursor, conn, current_time, metal_plates)
                quality_test_results = perform_quality_tests(cursor, conn, metal_plates, current_time)
                
                if quality_test_results['passed']:
                    dishwasher_result = assemble_dishwashers(cursor, conn, metal_plates, fabrication_order, current_time)
                    total_dishwashers_produced += dishwasher_result['quantity_produced']
                    model_totals[model]['dishwashers'] += dishwasher_result['quantity_produced']
            
            current_time += timedelta(minutes=INTERVAL_MINUTES)
            
            if interval_count % 10 == 0:
                conn.commit()
        
        check_and_complete_maintenance(cursor, conn, current_time)
        conn.commit()
        
        return {
            'statusCode': 200,
            'body': {
                'message': '24-hour shift simulation completed',
                'shift_start': shift_start.isoformat(),
                'shift_end': shift_end.isoformat(),
                'intervals_processed': interval_count,
                'total_plates_produced': total_plates_produced,
                'total_dishwashers_produced': total_dishwashers_produced,
                'model_breakdown': model_totals
            }
        }
        
    except Exception as e:
        logger.error(f"Error in lambda_handler: {str(e)}")
        if conn:
            conn.rollback()
        raise
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

def check_and_complete_maintenance(cursor, conn, current_time):
    cursor.execute("""
        SELECT DISTINCT m.machine_id, m.machine_model, ml.end_time
        FROM machines m
        JOIN maintenance_logs ml ON m.machine_id = ml.machine_id
        WHERE m.machine_status = 'maintenance'
        AND ml.end_time <= %s
        AND ml.end_time = (
            SELECT MAX(ml2.end_time) 
            FROM maintenance_logs ml2 
            WHERE ml2.machine_id = m.machine_id
        )
    """, (current_time,))
    
    completed_maintenance = cursor.fetchall()
    
    for machine_id, machine_model, maintenance_end_time in completed_maintenance:
        cursor.execute("UPDATE machines SET machine_status = 'running' WHERE machine_id = %s", (machine_id,))
    
    if completed_maintenance:
        conn.commit()

def simulate_production_metrics(cursor, machine_id, current_time, plates_produced, efficiency):
    cursor.execute("""
        SELECT COUNT(*) as batch_count
        FROM metal_plate_batches mpb
        WHERE mpb.machine_id = %s
        AND mpb.production_time > COALESCE((
            SELECT MAX(end_time) FROM maintenance_logs 
            WHERE machine_id = %s AND end_time IS NOT NULL
        ), '1900-01-01')
    """, (machine_id, machine_id))
    
    result = cursor.fetchone()
    batches_since_maintenance = float(result[0] if result else 0)
    degradation_factor = min(batches_since_maintenance / 50.0, 1.0)
    
    base_blade_feed_speed = 0.25
    base_cutting_pressure = 50.0
    efficiency = float(efficiency)
    efficiency_factor = max(0.45, efficiency)
    
    blade_feed_speed = float(base_blade_feed_speed) * (0.7 + (0.3 * efficiency_factor))
    blade_feed_speed = blade_feed_speed * (1.0 - (float(degradation_factor) * 0.3))
    
    cutting_pressure = float(base_cutting_pressure) * (0.9 + (0.2 * (1.0 - efficiency_factor)))
    cutting_pressure = cutting_pressure * (1.0 + (float(degradation_factor) * 0.4))
    
    blade_feed_speed += float(random.uniform(-0.02, 0.02))
    cutting_pressure += float(random.uniform(-2.0, 2.0))
    
    blade_feed_speed = max(0.10, min(0.30, blade_feed_speed))
    cutting_pressure = max(35.0, min(70.0, cutting_pressure))
    efficiency_percentage = round(efficiency * 100, 2)
    
    cursor.execute("""
        INSERT INTO production_metrics 
        (machine_id, timestamp, parts_cut_total, blade_feed_speed, cutting_pressure, efficiency)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (machine_id, current_time, plates_produced, 
          round(blade_feed_speed, 3), round(cutting_pressure, 1), efficiency_percentage))
    
    new_status = 'maintenance' if plates_produced == 0 else 'running'
    cursor.execute("UPDATE machines SET machine_status = %s WHERE machine_id = %s", (new_status, machine_id))
    
    return {
        'blade_feed_speed': float(blade_feed_speed),
        'cutting_pressure': float(cutting_pressure),
        'efficiency_percentage': float(efficiency_percentage),
        'degradation_factor': float(degradation_factor),
        'batches_since_maintenance': float(batches_since_maintenance)
    }

def handle_efficiency_based_maintenance(cursor, conn, current_time, metal_plates):
    machine_id = metal_plates['machine_id']
    
    if metal_plates['quantity'] == 0 or 'metrics' not in metal_plates:
        return
    
    current_efficiency = metal_plates['metrics']['efficiency_percentage'] / 100.0
    
    if current_efficiency < EFFICIENCY_THRESHOLD:
        cursor.execute("""
            SELECT COUNT(*) FROM maintenance_logs 
            WHERE machine_id = %s 
            AND (
                (start_time <= %s AND end_time >= %s) OR
                (start_time > %s)
            )
        """, (machine_id, current_time, current_time, current_time))
        
        if cursor.fetchone()[0] > 0:
            return
        
        cursor.execute("SELECT * FROM machines WHERE machine_id = %s", (machine_id,))
        machine_result = cursor.fetchone()
        if not machine_result:
            return
        
        machine_columns = [desc[0] for desc in cursor.description]
        machine = dict(zip(machine_columns, machine_result))
        
        maintenance_duration = random.randint(30, 90)
        end_time = current_time + timedelta(minutes=maintenance_duration)
        reason = f'Efficiency-based maintenance - efficiency dropped to {current_efficiency:.1%}'
        
        cursor.execute("""
            INSERT INTO maintenance_logs 
            (production_line_id, machine_id, start_time, end_time,
             reason, impact_description, reported_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (machine['production_line_id'], machine_id, current_time, end_time,
              reason, f'Maintenance triggered due to efficiency below {EFFICIENCY_THRESHOLD:.1%}',
              'AutomatedSystem'))
        
        update_machine_configuration(cursor, machine_id, current_time)

def update_machine_configuration(cursor, machine_id, current_time):
    cursor.execute("SELECT * FROM machine_configurations WHERE machine_id = %s", (machine_id,))
    config_result = cursor.fetchone()
    
    if config_result:
        config_columns = [desc[0] for desc in cursor.description]
        config = dict(zip(config_columns, config_result))
        
        cursor.execute("""
            UPDATE machine_configurations 
            SET blade_angle = %s, blade_height = %s, blade_rotation_speed = %s, last_updated = %s 
            WHERE config_id = %s
        """, (45.0, 3.0, 1000.0, current_time, config['config_id']))
    else:
        cursor.execute("""
            INSERT INTO machine_configurations 
            (machine_id, active_cutting_program, blade_angle,
             blade_height, blade_rotation_speed, last_updated)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (machine_id, 'METAL_CUT_V1', 45.0, 3.0, 1000.0, current_time))

def check_fabrication_order(cursor, conn, model, shift_start):
    while cursor.nextset():
        pass
    
    cursor.execute("SELECT * FROM fabrication_orders WHERE dishwasher_model = %s AND status = %s", (model, 'active'))
    existing_orders = cursor.fetchall()
    
    while cursor.nextset():
        pass
    
    if not existing_orders:
        cursor.execute("SELECT line_id FROM production_lines WHERE dishwasher_model = %s", (model,))
        production_line_result = cursor.fetchall()
        
        while cursor.nextset():
            pass
        
        if production_line_result:
            production_line_id = production_line_result[0][0]
        else:
            cursor.execute("""
                INSERT INTO production_lines 
                (line_name, dishwasher_model, status, capacity_per_hour)
                VALUES (%s, %s, %s, %s)
            """, (f"Line_{model}", model, 'active', 120))
            
            production_line_id = cursor.lastrowid
            conn.commit()
            
            while cursor.nextset():
                pass
        
        start_date = shift_start.date()
        due_date = start_date + timedelta(days=7)
        
        cursor.execute("""
            INSERT INTO fabrication_orders 
            (dishwasher_model, quantity, production_line_id, 
             start_date, due_date, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (model, 500, production_line_id, start_date, due_date, 'active'))
        
        order_id = cursor.lastrowid
        conn.commit()
        
        while cursor.nextset():
            pass
        
        return {
            'order_id': order_id,
            'dishwasher_model': model,
            'quantity': 500,
            'production_line_id': production_line_id,
            'start_date': start_date,
            'due_date': due_date,
            'status': 'active'
        }
    else:
        columns = [desc[0] for desc in cursor.description]
        return dict(zip(columns, existing_orders[0]))

def produce_metal_plates(cursor, conn, fabrication_order, current_time):
    cursor.execute("""
        SELECT * FROM machines 
        WHERE machine_model = %s AND production_line_id = %s
    """, ('LM-5000', fabrication_order['production_line_id']))
    
    machine_result = cursor.fetchone()
    
    if not machine_result:
        raise Exception("Laser metal machine LM-5000 not found")
    
    machine_columns = [desc[0] for desc in cursor.description]
    machine = dict(zip(machine_columns, machine_result))
    machine_id = machine['machine_id']
    
    efficiency = calculate_production_efficiency_with_maintenance_impact(cursor, machine_id, current_time)
    base_plates = 30
    plates_produced = max(0, int(base_plates * efficiency))
    
    batch_number = f"BATCH-{current_time.strftime('%Y%m%d%H%M')}-{random.randint(1000, 9999)}"
    batch_status = 'approved' if random.random() < 0.85 else 'rejected'
    
    cursor.execute("""
        INSERT INTO metal_plate_batches 
        (machine_id, fabrication_order_id, batch_number, 
         production_time, quantity, status)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (machine_id, fabrication_order['order_id'], batch_number,
          current_time, plates_produced, batch_status))
    
    batch_id = cursor.lastrowid
    metrics = simulate_production_metrics(cursor, machine_id, current_time, plates_produced, efficiency)
    
    return {
        'batch_id': batch_id,
        'machine_id': machine_id,
        'fabrication_order_id': fabrication_order['order_id'],
        'batch_number': batch_number,
        'production_time': current_time,
        'quantity': plates_produced,
        'status': batch_status,
        'metrics': metrics
    }

def calculate_production_efficiency_with_maintenance_impact(cursor, machine_id, current_time):
    interval_start = current_time
    interval_end = current_time + timedelta(minutes=INTERVAL_MINUTES)
    
    cursor.execute("""
        SELECT start_time, end_time FROM maintenance_logs 
        WHERE machine_id = %s 
        AND NOT (end_time <= %s OR start_time >= %s)
        ORDER BY start_time DESC
        LIMIT 1
    """, (machine_id, interval_start, interval_end))
    
    active_maintenance = cursor.fetchone()
    
    if active_maintenance:
        maintenance_start, maintenance_end = active_maintenance
        overlap_start = max(interval_start, maintenance_start)
        overlap_end = min(interval_end, maintenance_end)
        overlap_minutes = (overlap_end - overlap_start).total_seconds() / 60
        maintenance_percentage = overlap_minutes / INTERVAL_MINUTES
        return max(0.0, 1.0 - maintenance_percentage)
    
    cursor.execute("""
        SELECT end_time FROM maintenance_logs 
        WHERE machine_id = %s 
        AND end_time < %s 
        AND end_time >= %s
        ORDER BY end_time DESC
        LIMIT 1
    """, (machine_id, current_time, current_time - timedelta(minutes=60)))
    
    recent_maintenance = cursor.fetchone()
    
    if recent_maintenance:
        return random.uniform(0.95, 1.0)
    
    cursor.execute("""
        SELECT COUNT(*) as batch_count
        FROM metal_plate_batches mpb
        WHERE mpb.machine_id = %s
        AND mpb.production_time > COALESCE((
            SELECT MAX(end_time) FROM maintenance_logs 
            WHERE machine_id = %s AND end_time IS NOT NULL
        ), '1900-01-01')
    """, (machine_id, machine_id))
    
    result = cursor.fetchone()
    batches_since_maintenance = result[0] if result else 0
    
    base_efficiency = random.uniform(0.95, 1.0)
    degradation_per_batch = random.uniform(0.02, 0.05)
    efficiency = base_efficiency - (batches_since_maintenance * degradation_per_batch)
    
    hour = current_time.hour
    time_variation = 0.0
    
    if hour in [6, 7, 14, 15, 22, 23]:
        time_variation = random.uniform(-0.05, 0.0)
    elif hour in [2, 3, 4]:
        time_variation = random.uniform(-0.03, 0.0)
    
    efficiency += time_variation
    return max(0.45, min(1.0, efficiency))

def perform_quality_tests(cursor, conn, metal_batch, test_time):
    if metal_batch['quantity'] == 0:
        return {'passed': False, 'hardness_test': None, 'compression_test': None}
    
    batch_id = metal_batch['batch_id']
    tests_should_pass = (metal_batch['status'] == 'approved')
    
    hardness_tolerance = 0.5
    hardness_units = 'Mohs'
    hardness_threshold = 8.0
    
    if tests_should_pass:
        hardness_value = random.uniform(8.0, 9.5)
        hardness_passed = True
    else:
        hardness_value = random.uniform(7.0, 7.9)
        hardness_passed = False
    
    hardness_result = 'pass' if hardness_passed else 'fail'
    
    cursor.execute("""
        INSERT INTO quality_tests 
        (batch_id, test_type, test_timestamp, result, test_value, 
         tolerance, units, tested_by, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (batch_id, 'hardness', test_time, hardness_result, hardness_value,
          hardness_tolerance, hardness_units, 'AutomatedSystem', 
          f'Automated hardness test - threshold: {hardness_threshold} {hardness_units}'))
    
    hardness_test_id = cursor.lastrowid
    
    compression_tolerance = 50.0
    compression_units = 'PSI'
    compression_threshold = 900
    
    if tests_should_pass:
        compression_value = random.uniform(900, 1200)
        compression_passed = True
    else:
        compression_value = random.uniform(700, 899)
        compression_passed = False
    
    compression_result = 'pass' if compression_passed else 'fail'
    
    cursor.execute("""
        INSERT INTO quality_tests 
        (batch_id, test_type, test_timestamp, result, test_value, 
         tolerance, units, tested_by, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (batch_id, 'compression', test_time, compression_result, compression_value,
          compression_tolerance, compression_units, 'AutomatedSystem', 
          f'Automated compression test - threshold: {compression_threshold} {compression_units}'))
    
    compression_test_id = cursor.lastrowid
    overall_passed = hardness_passed and compression_passed
    
    return {
        'passed': overall_passed,
        'hardness_test': {
            'test_id': hardness_test_id,
            'test_value': hardness_value,
            'result': hardness_result,
            'tolerance': hardness_tolerance,
            'units': hardness_units
        },
        'compression_test': {
            'test_id': compression_test_id,
            'test_value': compression_value,
            'result': compression_result,
            'tolerance': compression_tolerance,
            'units': compression_units
        }
    }

def assemble_dishwashers(cursor, conn, metal_batch, fabrication_order, current_time):
    plates_available = metal_batch['quantity']
    
    if plates_available == 0:
        return {'production_id': None, 'quantity_produced': 0, 'machine_id': None}
    
    dishwashers_produced = plates_available // PLATES_PER_DISHWASHER
    dishwasher_model = fabrication_order['dishwasher_model']
    
    cursor.execute("""
        SELECT * FROM machines 
        WHERE machine_model = %s AND production_line_id = %s
    """, ('AS-2000', fabrication_order['production_line_id']))
    
    machine_result = cursor.fetchone()
    
    if not machine_result:
        raise Exception(f"Screwing machine AS-2000 not found for production line {fabrication_order['production_line_id']}")
    
    machine_columns = [desc[0] for desc in cursor.description]
    screwing_machine = dict(zip(machine_columns, machine_result))
    
    cursor.execute("""
        INSERT INTO dishwasher_assembly_batches 
        (machine_id, metal_batch_id, fabrication_order_id,
         production_date, quantity_produced, dishwasher_model, status,
         quality_check_passed, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (screwing_machine['machine_id'], metal_batch['batch_id'],
          fabrication_order['order_id'], current_time, dishwashers_produced,
          dishwasher_model, 'completed', True, 
          f'Automated production of {dishwashers_produced} {dishwasher_model} dishwashers'))
    
    production_id = cursor.lastrowid
    
    return {
        'production_id': production_id,
        'quantity_produced': dishwashers_produced,
        'machine_id': screwing_machine['machine_id']
    }
