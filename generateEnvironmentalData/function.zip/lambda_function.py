import json
import random
import boto3
from datetime import datetime
import logging
import uuid

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def generate_machine_data(machine_id):
    # Different ranges based on machine type
    is_laser = machine_id in [1, 3]
    
    data = {
        "machine_id": machine_id,
        "timestamp": datetime.now().isoformat(),
        "ambient_temp": round(random.uniform(22.0, 28.0) if is_laser else random.uniform(18.0, 24.0), 2),
        "vibration_level": round(random.uniform(2.0, 4.0) if is_laser else random.uniform(1.0, 2.5), 2),
        "power_stability": round(random.uniform(95.0, 99.9) if is_laser else random.uniform(97.0, 99.9), 2)
    }
    return data

def lambda_handler(event, context):
    logger.info("Initializing environmental data generation")
    kinesis = boto3.client('kinesis')
    
    try:
        # Generate data for all machines at once
        all_machines_data = {
            "timestamp": datetime.now().isoformat(),
            "machines": []
        }
        
        # Generate data for each machine
        for machine_id in [1, 2, 3, 4]:
            machine_data = generate_machine_data(machine_id)
            all_machines_data["machines"].append(machine_data)
            logger.info(f"Generated data for Machine {machine_id}: {json.dumps(machine_data)}")
        
        # Send all data in a single record
        response = kinesis.put_record(
            StreamName='environmental-data-stream',
            Data=json.dumps(all_machines_data),
            PartitionKey='1'  # Single partition key for one shard
        )
        
        logger.info(f"Data sent to Kinesis for all machines. "
                   f"Sequence: {response['SequenceNumber']}, "
                   f"Shard: {response['ShardId']}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Environmental data sent to Kinesis',
                'data': all_machines_data
            })
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        raise e
